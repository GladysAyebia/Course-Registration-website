function createHeart() {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.style.width = `${Math.floor(Math.random() * 65) + 10}px`;
    heart.style.height = heart.style.width;
    heart.style.left = `${Math.floor(Math.random() * 100)}%`;
    heart.style.background = `rgba(255, ${Math.floor(Math.random() * 55) + 100}, ${Math.floor(Math.random() * 55) + 100}, 1)`;
    const duration = Math.floor(Math.random() * 5) + 5;
    heart.style.animation = `love ${duration}s ease-in infinite`;
    return heart;
}

const container = document.querySelector('.bg_heart');

function removeHearts() {
    const hearts = container.querySelectorAll('.heart');
    hearts.forEach((heart) => {
        const top = parseFloat(getComputedStyle(heart).getPropertyValue('top'));
        if (top <= -100) {
            heart.remove();
        }
    });
}

function addHeart() {
    const heart1 = createHeart();
    container.appendChild(heart1);
    setTimeout(removeHearts, 1000);
}

const love = setInterval(addHeart, 500);

const text = `You’re my favorite line of code; I love you more than a perfectly written script! You've animated my heart in ways no CSS or JavaScript ever could😂. Oh, hey, just so you know, if my love for you were code, it would be an infinite loop of "I <3 U". I miss you, Bee.😁`;
let index = 0;

function typeText() {
    if (index < text.length) {
        document.getElementById('typingMessage').innerHTML += text.charAt(index);
        index++;
        setTimeout(typeText, 100); // Adjust speed here
    }
}

typeText();
